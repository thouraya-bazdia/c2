# VideoSDK Google Plugin

Agent Framework plugin for realtime, LLM, TTS, and STT  services from Google.

## Installation

```bash
pip install videosdk-plugins-google
```