---
name: Question
about: Ask for help with an issue you're facing
title: ''
labels: question
assignees: ''

---

<!--
Hello! Thanks for taking the time to ask a question.

Before creating this issue, we kindly ask that you use the search functionality
to see if anyone else has already asked this question.
Please include details such as environment, package versions, minimal examples,
and error logs, if applicable.

Feel free to join us in the #agents channel on our Discord, and ask your question
there to get quicker help from us and the community:

https://discord.com/invite/f2WsNDN9S5
-->