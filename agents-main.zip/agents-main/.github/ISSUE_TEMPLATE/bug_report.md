---
name: Bug report
about: Let us know of an issue so we can fix it
title: ''
labels: bug
assignees: ''

---

<!--
Hello! Thanks for taking the time to file a bug report.

Before creating this issue, we kindly ask that you use the search functionality
to see if anyone else has already reported this issue.
Please include details such as environment, package versions, minimal examples,
and error logs, if applicable.
-->